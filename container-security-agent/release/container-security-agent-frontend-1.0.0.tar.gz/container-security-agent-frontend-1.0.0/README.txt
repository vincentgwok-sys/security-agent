============================================================
 Container Security Agent 前端 v1.0.0
============================================================

环境要求
--------
  • Python 3（用于内置 HTTP 服务器）
    或任意 HTTP 服务器（nginx、Apache、Node.js serve 等）

快速开始
--------
  1. 确保后端已启动在 http://localhost:8080
  2. 双击 start.bat (Windows) 或执行 ./start.sh (Linux/Mac)
  3. 浏览器打开 http://localhost:5173

独立部署
--------
  如果后端不在 localhost:8080，或需要部署到生产环境：

  方案 A：使用后端自带的前端
    后端 JAR 已内嵌前端文件，直接访问 http://localhost:8080 即可。
    无需单独使用此前端包。

  方案 B：配置反向代理（nginx 示例）
    location / {
        root /path/to/frontend-files;
        try_files $uri $uri/ /index.html;
    }
    location /api/ {
        proxy_pass http://backend:8080;
    }

  方案 C：修改 Vite 构建配置
    编辑 frontend/vite.config.js 中的 server.proxy.target，
    重新 npm run build 后部署。

目录说明
--------
  index.html    入口页面
  assets/       JS 和 CSS 静态资源（Vite 构建产物）
