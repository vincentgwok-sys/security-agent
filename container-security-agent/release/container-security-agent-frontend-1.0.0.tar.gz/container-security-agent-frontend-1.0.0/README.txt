============================================================
 Container Security Agent 前端 v1.0.0
============================================================

环境要求
--------
  • Python 3
    或任意 HTTP 服务器（nginx、Apache、Node.js serve 等）

快速开始
--------
  1. 确保后端已启动在 http://localhost:8080
  2. 双击 start.bat (Windows) 或执行 ./start.sh (Linux/Mac)
  3. 浏览器打开 http://localhost:5173

独立部署
--------
  方案 A（推荐）：使用后端自带前端
    后端 JAR 已内嵌前端，直接访问 http://localhost:8080

  方案 B：配置反向代理（nginx）
    location / {
        root /path/to/frontend-files;
        try_files $uri $uri/ /index.html;
    }
    location /api/ {
        proxy_pass http://backend:8080;
    }
