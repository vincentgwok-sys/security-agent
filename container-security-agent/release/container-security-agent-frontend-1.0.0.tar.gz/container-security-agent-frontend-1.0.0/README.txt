============================================================
 Container Security Agent 前端 v1.0.0
============================================================

环境要求
--------
  • Python 3
  • bash (Linux/Mac)

快速开始
--------
  1. 确保后端已启动在 http://localhost:8080
  2. 双击 start.bat (Windows) 或 ./start.sh (Linux/Mac)
  3. 浏览器打开 http://localhost:5173

独立部署
--------
  推荐使用后端自带前端（后端 JAR 已内嵌，直接访问 8080 端口）

  nginx 反向代理示例：
    location / {
        root /path/to/frontend-files;
        try_files $uri $uri/ /index.html;
    }
    location /api/ {
        proxy_pass http://backend:8080;
    }
