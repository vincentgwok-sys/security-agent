#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "============================================"
echo " Container Security Agent (前端)"
echo "============================================"

PYTHON=""
for py in python3 python; do
  if command -v "$py" &>/dev/null; then
    PYTHON="$py"
    break
  fi
done

if [ -z "$PYTHON" ]; then
  echo "[ERROR] 未找到 Python 3。请安装 Python 3 并加入 PATH。"
  echo "        也可以使用任意 HTTP 服务器（nginx、Apache 等）托管此目录。"
  exit 1
fi

echo "启动前端: http://localhost:5173"
echo "注意: 前端需要后端在 http://localhost:8080 运行"
echo "按 Ctrl+C 停止服务"
echo ""

cd "$SCRIPT_DIR" && "$PYTHON" -m http.server 5173
