@echo off
setlocal
set "SCRIPT_DIR=%~dp0"

echo ============================================
echo  Container Security Agent (前端^)
echo ============================================

:: 检查 Python
where python >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set PYTHON=python
) else (
    where python3 >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        set PYTHON=python3
    )
)

if not defined PYTHON (
    echo [ERROR] 未找到 Python 3。请安装 Python 3 并加入 PATH。
    echo         也可以使用任意 HTTP 服务器（nginx、Apache 等）托管此目录。
    pause
    exit /b 1
)

echo 启动前端: http://localhost:5173
echo 注意: 前端需要后端在 http://localhost:8080 运行
echo       如果前后端不同源，请配置反向代理或 CORS
echo 按 Ctrl+C 停止服务
echo.

cd /d "%SCRIPT_DIR%" && %PYTHON% -m http.server 5173
pause
